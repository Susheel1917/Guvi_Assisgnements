Celsius = int(raw_input("Enter a temperature in Celsius: "))
Fahrenheit = 9.0/5.0 * Celsius + 32
print "Temperature:", Celsius, "Celsius = ", Fahrenheit, " F"