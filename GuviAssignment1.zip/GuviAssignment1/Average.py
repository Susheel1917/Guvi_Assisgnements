count = 0
while count<10:
    n = float(input('Enter a number: '))
    sum = sum + n
    count = count + 1

average = sum/10

print(f'The average of these numbers is: {average}')