# make a function that will return the index of the element we are #looking for.
def binary_search(arr,element,low,high):
     
    # If the lower index of the array exceeds the higher index,
    # that means that the element could not be found in the array.
    if low<=high:
         
        # find the middle index of the array 
        mid=(low+high)//2
 
        #If the middle element is the element we are looking for,
        # return the index of middle element
        if element==arr[mid]:
            print(mid)
         
        # if the element is greater than middle element,
        # search for the element in the second half
        elif element > arr[mid]:
            binary_search(arr,element,mid+1,high)
             
        # if the element is lesser than middle element,
        # search for the element in the first half
        else:
            binary_search(arr,element,low,mid-1) 
         
    else:
        print("Element not found")